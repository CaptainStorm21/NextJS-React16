import Head from "next/head";
import HeaderMain from '../layouts/header_main'
export default () => (
  <>
    <Head>
      <title>Australian Securities</title>
     <link rel="icon" href="/favicon.ico" />
    </Head>
    <header>
      <HeaderMain/>
    </header>
    <main>
      <div className="p-4 shadow rounded bg-white">
        <h1 className="text-purple leading-normal">Next.js</h1>
        <p className="text-grey-dark">with Tailwind CSS</p>
      </div>
    </main>
    <footer></footer>
  </>
);



