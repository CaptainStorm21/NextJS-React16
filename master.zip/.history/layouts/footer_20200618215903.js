import React from "react";

const Footer = () => {
  return (
    <>
      <div className="bg-black text-white  flex-grow p-8">
        <a
          href="https://australiansecurities.com.au/contact-us"
          target="_blank"
          passHref={true}
        >
          Contact |
          <a
            href="https://australiansecurities.com.au/privacy-policy/"
            passHref={true}
            target="_blank"
          >
            Privacy Statement
          </a>
        </a>
        <div className="p-8">
          Copyright© ASL’ s Financial Services Credit Licence Number 260499. All
          rights reserved.
        </div>
      </div>
    </>
  );
};

export default Footer;