import React from 'react'

const footer = () => {
    return (
        <div>
            
        </div>
    )
}

export default footer
