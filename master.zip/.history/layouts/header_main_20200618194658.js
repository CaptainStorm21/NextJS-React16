import React from "react";
import Link from "next/link";

const HeaderMain = () => (
  <>
    <header>
      <div className="container">
        <Link href="/">
          <a className="">News</a>
        </Link>
        <Link href="/">
          <a className="">Turn on Help</a>
        </Link>
        <Link href="/">
          <a className="">Get Help</a>
        </Link>
        <Link href="/">
          <a className="">Account</a>
        </Link>
      </div>
    </header>
  </>
);

export default HeaderMain;
