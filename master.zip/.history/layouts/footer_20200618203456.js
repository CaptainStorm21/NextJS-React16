import React from 'react'

const Footer = () => {
    return (
        <div>
            
        </>
    )
}

export default Footer
