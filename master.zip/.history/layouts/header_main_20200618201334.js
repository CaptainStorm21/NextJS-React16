import React from "react";
import Link from "next/link";
//logo + links 
import Header_Sub from './header_sub';

const HeaderMain = () => (
  <>
    <header>
      <div className="flex items-end  h-24">
        <Link href="/">
          <a className="flex-1  text-center px-4 py-2 m-2">News</a>
        </Link>
        <Link href="/">
          <a className="flex-1  text-center px-4 py-2 m-2">Turn on Help</a>
        </Link>
        <Link href="/">
          <a className="flex-1  text-center px-4 py-2 m-2">Get Help</a>
        </Link>
        <Link href="/">
          <a className="flex-1  text-center px-4 py-2 m-2">Account</a>
        </Link>
      </div>
      <>,</>
    </header>
  </>
);

export default HeaderMain;
