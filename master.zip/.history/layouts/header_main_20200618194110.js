
import React, { Component } from "react";
import Link from "next/link";

const HeaderMain = () => (
    <>
        <header>
            <div className = ""
    </header>
    </>
);

export default HeaderMain;