import React from 'react'

const Footer = () => {
    return (
      <>
        <div class="min-h-screen flex flex-col font-sans">
          <div class="flex-grow p-8 text-2xl">Main content area!</div>
          <div class="bg-indigo text-white text-2xl p-8">Footer!</div>
        </div>
      </>
    );
}

export default Footer
