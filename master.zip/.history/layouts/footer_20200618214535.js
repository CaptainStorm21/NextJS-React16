import React from "react";
import Link from "next/link";

const Footer = () => {
  return (
    <>
      <div className="flex-grow p-8">
              <ul>
                  <li></li>
          <Link href="">
            <a>About</a>
          </Link>
          |
          <Link href="">
            <a>About</a>
          </Link>
        </ul>
        <div className="bg-indigo text-white text-2xl p-8">
          Copyright © ASL’s Financial Services Credit Licence Number 260499. All
          rights reserved.
        </div>
      </div>
    </>
  );
};

export default Footer;
