import React from "react";
import Link from "next/link";

const Footer = () => {
  return (
    <>
      <div className="flex-grow p-8">
        <ul>
          <li>
            <a
              href="https://australiansecurities.com.au/contact-us"
              passHref={true}
            >
              <a>Contact</a>
            </a>
          </li>
          |
          <li>
            <Link
              href="https://australiansecurities.com.au/privacy-policy/"
              passHref={true}
            >
              <a>Privacy Statement</a>
            </Link>
          </li>
        </ul>
        <div className="bg-indigo text-white text-2xl p-8">
          Copyright © ASL’s Financial Services Credit Licence Number 260499. All
          rights reserved.
        </div>
      </div>
    </>
  );
};

export default Footer;
