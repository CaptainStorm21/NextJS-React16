
import React, { Component } from "react";
import Link from "next/link";

const HeaderMain = () => (
  <>
    <header>
      <div className="container">
        <Link href="/">
          <a className="">Home</a>
        </Link>
        <Link href="/contact">
          <a className="">Contact</a>
        </Link>
        <Link href="/about">
          <a className="">About</a>
        </Link>
        <Link href="/users">
          <a className="nav-item nav-link">Users</a>
        </Link>
      </div>
    </header>
  </>
);

export default HeaderMain;