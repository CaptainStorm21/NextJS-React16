import React from "react";
import Link from "next/link";

const HeaderMain = () => (
  <>
    <header>
      <div className="flex items-stretch  h-24">
        <Link href="/">
          <a className="flex-1 text-gray-700 text-center bg-gray-400 px-4 py-2 m-2">
            News
          </a>
        </Link>
        <Link href="/">
          <a className="">Turn on Help</a>
        </Link>
        <Link href="/">
          <a className="">Get Help</a>
        </Link>
        <Link href="/">
          <a className="">Account</a>
        </Link>
      </div>
    </header>
  </>
);

export default HeaderMain;
