import React from 'react'

const Footer = () => {
    return (
      <>
        <div className="min-h-screen flex flex-col font-sans">
                <div className="flex-grow p-8">
                </div>
          <div className="bg-indigo text-white text-2xl p-8">
            Copyright © ASL’s Financial Services Credit Licence Number 260499.
            All rights reserved.
          </div>
        </div>
      </>
    );
}

export default Footer
